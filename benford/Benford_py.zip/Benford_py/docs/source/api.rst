benford package
===============

benford.benford module
----------------------

.. automodule:: benford.benford
   :members:
   :undoc-members:
   :show-inheritance:


benford.expected module
-----------------------

.. automodule:: benford.expected
   :members:
   :undoc-members:
   :show-inheritance:


benford.stats module
--------------------

.. automodule:: benford.stats
   :members:
   :undoc-members:
   :show-inheritance:


benford.viz module
------------------

.. automodule:: benford.viz
   :members:
   :undoc-members:
   :show-inheritance:

