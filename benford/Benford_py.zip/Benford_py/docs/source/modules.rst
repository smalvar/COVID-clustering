benford
=======

.. toctree::
   :maxdepth: 2

   api
